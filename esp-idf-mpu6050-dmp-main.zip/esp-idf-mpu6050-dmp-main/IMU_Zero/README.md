# IMU_Zero
Sensor calibration for using DMP.   

# Configuration

![config-IMU_Zero-1](https://user-images.githubusercontent.com/6020549/224453127-936166c6-803c-4edf-bbb8-f0371fc07de9.jpg)
![config-IMU_Zero-2](https://user-images.githubusercontent.com/6020549/224453129-a0913f85-20bb-4760-821c-279a260f0c00.jpg)
